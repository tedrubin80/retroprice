
const express = require('express');
const app = express();
const fs = require('fs');
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post('/ebay-account-deletion', (req, res) => {
  const body = req.body;
  const timestamp = new Date().toISOString();

  fs.appendFile('deletion_log.json', `${timestamp} - ${JSON.stringify(body)}\n`, err => {
    if (err) console.error('Error writing to log file', err);
  });

  console.log('Received deletion notice from eBay:', body);

  res.status(200).send('Received');
});

app.get('/', (req, res) => {
  res.send('eBay Notification Endpoint Running');
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

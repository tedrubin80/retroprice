
# eBay Account Deletion Endpoint

This is a basic Node.js Express application that handles eBay's Marketplace Account Deletion notifications.

## How to Use

1. Install dependencies:
   ```
   npm install
   ```

2. Start the server:
   ```
   node ebay-endpoint.js
   ```

3. (Optional) Use Ngrok to expose the endpoint:
   ```
   ngrok http 3000
   ```

4. Register your endpoint URL at:
   https://developer.ebay.com/

## Endpoint
- `POST /ebay-account-deletion` - Receives eBay account deletion notifications
